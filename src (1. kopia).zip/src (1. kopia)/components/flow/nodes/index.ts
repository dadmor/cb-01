// ===== src/components/flow/nodes/index.ts =====
export { MainNode } from "./MainNode";
export { DecisionNode } from "./DecisionNode";

